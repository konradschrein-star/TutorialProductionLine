"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { V2Button, V2Input, GlassCard } from "../../_components";

/**
 * "Initial Keywords" — the hub-web-native fallback list of the ~2,150
 * guide-realm keywords carried over from the previous tutorial tool.
 *
 * Unlike the "Keyword Tool" sub-tab (an iframe into a separate app) and the
 * "My claimed keywords" queue (which calls that app's HTTP API), this reads
 * hub-web's OWN `seed_keywords` table via /api/production/keywords/seed. So it
 * keeps working when the Keyword Tool is down — the VA can still find a keyword
 * and push it straight into Create. That is the point of the fallback.
 *
 * Picking one hands (title, `seed:<id>`) up to the Create form via onUseSeed;
 * the parent switches to the Create tab and prefills it.
 */

interface SeedKeyword {
  id: number;
  title: string;
  software: string | null;
  contentType: string | null;
  lengthClass: string | null;
  durationSec: number | null;
  referenceUrl: string | null;
  made: boolean;
}

interface SeedResponse {
  total: number;
  offset: number;
  limit: number;
  hasMore: boolean;
  keywords: SeedKeyword[];
}

// The length classes present in the seed set (from kt_keywords.length_class).
const LENGTH_CLASSES = [
  "<3min",
  "3-6min",
  "6-10min",
  "10-20min",
  "20-40min",
  "40-60min",
  "1-2hr",
  "2hr+",
];

const PAGE = 40;

export interface InitialKeywordsProps {
  /** Load a seed keyword into the Create form and switch to that tab. */
  onUseSeed: (seed: { id: number; title: string }) => void;
}

export function InitialKeywords({ onUseSeed }: InitialKeywordsProps) {
  const [search, setSearch] = useState("");
  const [dSearch, setDSearch] = useState("");
  // Standard filter: default to "under 3 minutes" — the owner's requested
  // default, since tutorials are produced short-form. The VA can clear it.
  const [lengths, setLengths] = useState<string[]>(["<3min"]);

  const [rows, setRows] = useState<SeedKeyword[]>([]);
  const [total, setTotal] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const reqId = useRef(0);

  // Debounce the search box.
  useEffect(() => {
    const t = setTimeout(() => setDSearch(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);

  const buildQuery = useCallback(
    (offset: number) => {
      const q = new URLSearchParams({
        offset: String(offset),
        limit: String(PAGE),
      });
      if (dSearch) q.set("search", dSearch);
      if (lengths.length) q.set("length", lengths.join(","));
      return q.toString();
    },
    [dSearch, lengths],
  );

  const loadFirst = useCallback(async () => {
    const my = ++reqId.current;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/production/keywords/seed?${buildQuery(0)}`);
      const body = (await res.json()) as SeedResponse & { error?: string };
      if (my !== reqId.current) return;
      if (!res.ok) throw new Error(body.error ?? `HTTP ${res.status}`);
      setRows(body.keywords);
      setTotal(body.total);
      setHasMore(body.hasMore);
    } catch (e) {
      if (my === reqId.current)
        setError(e instanceof Error ? e.message : String(e));
    } finally {
      if (my === reqId.current) setLoading(false);
    }
  }, [buildQuery]);

  useEffect(() => {
    void loadFirst();
  }, [loadFirst]);

  const loadMore = useCallback(async () => {
    if (loadingMore || !hasMore) return;
    const my = reqId.current;
    setLoadingMore(true);
    try {
      const res = await fetch(
        `/api/production/keywords/seed?${buildQuery(rows.length)}`,
      );
      const body = (await res.json()) as SeedResponse & { error?: string };
      if (my !== reqId.current) return;
      if (!res.ok) throw new Error(body.error ?? `HTTP ${res.status}`);
      setRows((prev) => {
        const seen = new Set(prev.map((k) => k.id));
        return [...prev, ...body.keywords.filter((k) => !seen.has(k.id))];
      });
      setHasMore(body.hasMore);
    } catch {
      // keep the list we have; a failed page just leaves the button
    } finally {
      setLoadingMore(false);
    }
  }, [buildQuery, hasMore, loadingMore, rows.length]);

  const toggleLength = (lc: string) =>
    setLengths((prev) =>
      prev.includes(lc) ? prev.filter((x) => x !== lc) : [...prev, lc],
    );

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <div
        style={{
          fontSize: 12,
          color: "var(--v2-text-2)",
          lineHeight: 1.6,
        }}
      >
        The starter keyword set carried over from the previous tutorial tool,
        stored inside this app. It stays available even if the live Keyword Tool
        is down — pick one and it goes straight into Create.
      </div>

      {/* Filters */}
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
        <div style={{ flex: "1 1 240px", minWidth: 200 }}>
          <V2Input
            placeholder="Search title or software…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            fullWidth
          />
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {LENGTH_CLASSES.map((lc) => {
            const on = lengths.includes(lc);
            return (
              <button
                key={lc}
                onClick={() => toggleLength(lc)}
                style={{
                  padding: "4px 10px",
                  borderRadius: 999,
                  fontSize: 11,
                  fontWeight: 600,
                  cursor: "pointer",
                  border: "1px solid",
                  background: on
                    ? "rgba(var(--v2-accent-rgb), 0.15)"
                    : "transparent",
                  borderColor: on
                    ? "rgba(var(--v2-accent-rgb), 0.45)"
                    : "rgba(255,255,255,0.12)",
                  color: on ? "var(--v2-accent)" : "var(--v2-text-2)",
                }}
              >
                {lc}
              </button>
            );
          })}
        </div>
      </div>

      <div style={{ fontSize: 11, color: "var(--v2-text-2)" }}>
        {loading ? "Loading…" : `${total.toLocaleString("en-US")} keywords`}
      </div>

      {error && (
        <GlassCard style={{ padding: 16 }}>
          <div style={{ fontSize: 12, color: "#f87171" }}>
            Could not load initial keywords — {error}
          </div>
          <div style={{ marginTop: 10 }}>
            <V2Button variant="outline" onClick={() => void loadFirst()}>
              Try again
            </V2Button>
          </div>
        </GlassCard>
      )}

      {!error && (
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {rows.map((k) => (
            <div
              key={k.id}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12,
                padding: "9px 12px",
                borderRadius: 8,
                background: "rgba(255,255,255,0.03)",
                border: "1px solid transparent",
                opacity: k.made ? 0.6 : 1,
              }}
            >
              <div style={{ flex: 1, minWidth: 0 }}>
                <div
                  style={{
                    fontSize: 13,
                    fontWeight: 600,
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  }}
                >
                  {k.title}
                </div>
                <div
                  style={{ fontSize: 10, color: "var(--v2-text-2)", marginTop: 2 }}
                >
                  {k.software ?? "no software"}
                  {k.lengthClass ? ` · ${k.lengthClass}` : ""}
                  {k.contentType ? ` · ${k.contentType}` : ""}
                  {k.made ? " · already made" : ""}
                </div>
              </div>
              {k.referenceUrl && (
                <a
                  href={k.referenceUrl}
                  target="_blank"
                  rel="noreferrer"
                  style={{
                    fontSize: 10,
                    color: "var(--v2-text-2)",
                    textDecoration: "underline",
                    whiteSpace: "nowrap",
                  }}
                >
                  reference
                </a>
              )}
              <V2Button
                variant={k.made ? "outline" : "accent"}
                onClick={() => onUseSeed({ id: k.id, title: k.title })}
                title="Load this keyword into Create"
              >
                {k.made ? "Make again" : "Create tutorial"}
              </V2Button>
            </div>
          ))}

          {!loading && rows.length === 0 && (
            <div
              style={{
                fontSize: 12,
                color: "var(--v2-text-2)",
                padding: "24px 0",
                textAlign: "center",
              }}
            >
              No keywords match your filters.
            </div>
          )}

          {hasMore && (
            <div style={{ display: "flex", justifyContent: "center", marginTop: 8 }}>
              <V2Button
                variant="outline"
                onClick={() => void loadMore()}
                disabled={loadingMore}
              >
                {loadingMore ? "Loading…" : "Load more"}
              </V2Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
