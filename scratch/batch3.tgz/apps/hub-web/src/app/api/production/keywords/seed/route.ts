import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { getSession } from "@/lib/auth/session";
import { hasPermission } from "@/lib/auth/rbac";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

/**
 * GET /api/production/keywords/seed
 *
 * The "Initial Keywords" fallback list — the ~2,150 guide-realm keywords from
 * the previous tutorial tool, copied into hub-web's OWN Postgres (see migration
 * 0065). This route reads ONLY that local table and never touches the Keyword
 * Tool, so it keeps working when the Keyword Tool app is down. That resilience
 * is the entire reason the fallback exists (owner, 2026-08-24: "so that if the
 * keyword tool breaks the old keywords can be utilized in the workflow").
 *
 * Query params:
 *   search   — matches title OR software (case-insensitive substring)
 *   length   — CSV of length_class values (e.g. "<3min,3-6min")
 *   under3   — "1" to force duration_sec < 180 (the standard short filter)
 *   offset / limit — pagination (limit capped at 100)
 *
 * Each row carries `made` — whether a tutorial job already references it
 * (keyword_ref = 'seed:<id>') — so the VA does not repeat one, exactly as the
 * board would show. Requires view:production.
 */
export async function GET(request: Request): Promise<NextResponse> {
  const session = await getSession();
  if (!session || !hasPermission(session, "view:production")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const url = new URL(request.url);
  const search = (url.searchParams.get("search") ?? "").trim();
  const under3 = url.searchParams.get("under3") === "1";
  const lengths = (url.searchParams.get("length") ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  const offset = Math.max(0, Number(url.searchParams.get("offset")) || 0);
  const limit = Math.min(100, Math.max(1, Number(url.searchParams.get("limit")) || 40));

  // Build the WHERE with parameterised fragments (never string-interpolate the
  // user's search into SQL).
  const conds = [sql`TRUE`];
  if (search) {
    const like = `%${search}%`;
    conds.push(sql`(sk.title ILIKE ${like} OR sk.software ILIKE ${like})`);
  }
  if (under3) {
    conds.push(sql`sk.duration_sec < 180`);
  }
  if (lengths.length > 0) {
    conds.push(
      sql`sk.length_class IN (${sql.join(
        lengths.map((l) => sql`${l}`),
        sql`, `,
      )})`,
    );
  }
  const where = sql.join(conds, sql` AND `);

  // db.execute() returns the rows directly as an array (postgres-js driver),
  // not a { rows } wrapper — see analytics-repository.ts.
  const countRows = (await db.execute<{ n: number }>(
    sql`SELECT COUNT(*)::int AS n FROM seed_keywords sk WHERE ${where}`,
  )) as unknown as Array<{ n: number }>;
  const total = Number(countRows[0]?.n ?? 0);

  const rows = (await db.execute<{
    id: number;
    title: string;
    software: string | null;
    content_type: string | null;
    length_class: string | null;
    duration_sec: number | null;
    video_id: string | null;
    made: boolean;
  }>(
    sql`
      SELECT sk.id, sk.title, sk.software, sk.content_type, sk.length_class,
             sk.duration_sec, sk.video_id,
             EXISTS (
               SELECT 1 FROM tutorial_jobs tj
               WHERE tj.keyword_ref = 'seed:' || sk.id
             ) AS made
      FROM seed_keywords sk
      WHERE ${where}
      ORDER BY (sk.duration_sec IS NULL), sk.duration_sec ASC, sk.id ASC
      LIMIT ${limit} OFFSET ${offset}
    `,
  )) as unknown as Array<{
    id: number;
    title: string;
    software: string | null;
    content_type: string | null;
    length_class: string | null;
    duration_sec: number | null;
    video_id: string | null;
    made: boolean;
  }>;

  const keywords = rows.map((r) => ({
    id: r.id,
    title: r.title,
    software: r.software,
    contentType: r.content_type,
    lengthClass: r.length_class,
    durationSec: r.duration_sec,
    referenceUrl: r.video_id
      ? `https://www.youtube.com/watch?v=${r.video_id}`
      : null,
    made: Boolean(r.made),
  }));

  return NextResponse.json({
    total,
    offset,
    limit,
    hasMore: offset + keywords.length < total,
    keywords,
  });
}
